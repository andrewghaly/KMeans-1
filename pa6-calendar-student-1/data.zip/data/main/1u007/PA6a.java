package edu.wit.cs.comp1000;

public class PA6a {
	
	static final String E_YEAR = "The year must be positive!";
	
	static final String E_DAY = "The day of January 1st must be between 0 and 6!";
	
	public static boolean isLeapYear(int year) {
		return false;
	}
	
	public static int printMonth(String month, int startDay, int numDays) {
		return 0;
	}

	public static void main(String[] args) {
	}

}
